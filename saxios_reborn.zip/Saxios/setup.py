import os
os.system('cls' if os.name == 'nt' else 'clear')  
print("💮 Saxios Setup Tool 🌸")
print("[\x1b[38;5;1m1\033[0m] setup npm ")
print("[\x1b[38;5;1m2\033[0m] setup pip")
print("[\x1b[38;5;1m3\033[0m] pkg setup(termux)")
print("[\x1b[38;5;1m4\033[0m] Join Panel")
ask = input("Select A Number : ")

while True:
    if ask == "1":
        os.system("npm install set-cookie-parser")
        os.system("npm install user-agents")
        os.system("npm install colors")
        os.system("npm install socks")
        os.system("npm install gradient-string")
        os.system("npm install hpack")
        os.system("npm install minimist")
        os.system("npm install axios")
        os.system("npm install cheerio")
    elif ask == "2":
        os.system("pip install requests")
        os.system("pip install rich")
        os.system("pip install socks")
        os.system("pip install colorama")
        os.system("pip install socket")
        os.system("pip install subprocess")
        os.system("pip install random")
        
    elif ask == "3":
        os.system("pkg update && pkg upgrade")
        os.system("pkg install nodejs")
        os.system("pkg install python")
        os.system("pkg install git")
    elif ask == "5":
        os.system('cls' if os.name == 'nt' else 'clear')  
        os.system("python3 main.py")
    else:
        print("Number Not Found")
    
    ask = input("Enter : ")