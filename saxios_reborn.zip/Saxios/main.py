import os 
os.system('cls' if os.name == 'nt' else 'clear')  
while True:
     print("[\x1b[38;5;1m1\033[0m] Linux/MacOS (Bug Not Use) ")
     print("[\x1b[38;5;1m2\033[0m] Original (Recommended)")
     print("[\x1b[38;5;1m3\033[0m] Temux (Not Recommended)")
     print("[\x1b[38;5;1m4\033[0m] Why Does This Table Exist?")
     ask = input("Enter Device : ")
     if ask == "1":
         os.system("python3 saxioslinux.py")
         os.system("py3 saxioslinux.py")
         break
     elif ask == "4":
         print("Why is there a Device Selection Panel")
         print("I Found That Running On Some Operating Systems Has Some Different Errors That's Why This Table Is Here")
         print("Because We Cannot Fix 100% So If You Encounter Any Errors Please Contact @phuvanduc")
         break
     elif ask == "2":
         os.system("python3 saxios.py")
         os.system("py3 saxios.py")
         break
     elif ask == "3":
         os.system("python3 saxiostermux.py")
         break
     else:
         os.system('cls' if os.name == 'nt' else 'clear')  
         

    